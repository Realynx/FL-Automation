"""Automation curves use beats, unlike note and playlist native tick positions."""

from ._collection import checked_index
from .models import AutomationPointInfo
from .operations import Operations
from .records import Timebase


class AutomationCurve:
    def __init__(self, ops: Operations, channel: int) -> None:
        self._ops = ops
        self.channel = checked_index(channel)

    def list(self) -> tuple[AutomationPointInfo, ...]:
        return self._ops.query_automation_points(channel=self.channel)

    def list_text(self) -> str:
        return self._ops.list_automation_points(channel=self.channel)

    def add_beats(self, time: float, value: float, tension: float = 0) -> None:
        self._ops.add_automation_point(channel=self.channel, time_beats=time, value=value, tension=tension)

    def add_ticks(self, tick: int, value: float, tension: float = 0) -> None:
        self.add_beats(Timebase(self._ops.get_ppq()).beats(tick), value, tension)

    def delete(self, index: int) -> None:
        self._ops.delete_automation_point(channel=self.channel, index=checked_index(index))


class Automation:
    def __init__(self, ops: Operations) -> None:
        self._ops = ops

    def __getitem__(self, channel: int) -> AutomationCurve:
        return AutomationCurve(self._ops, channel)
