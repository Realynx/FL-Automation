"""Plugin catalogue, loaded-plugin parameter enumeration and parameter writes."""

from collections.abc import Iterator

from ._collection import checked_index, iter_pages
from .models import PluginParameterInfo
from .operations import Operations


class Parameters:
    def __init__(self, ops: Operations, channel_or_track: int, slot: int = -1) -> None:
        self._ops = ops
        self.channel_or_track = checked_index(channel_or_track)
        self.slot = checked_index(slot, minimum=-1, maximum=9)

    def list(self, filter: str | None = None) -> tuple[PluginParameterInfo, ...]:
        return tuple(iter_pages(lambda offset: self._ops.query_plugin_parameters(
            channel_or_track=self.channel_or_track, slot=self.slot, filter=filter, offset=offset)))

    def __iter__(self) -> Iterator[PluginParameterInfo]:
        return iter(self.list())

    def list_text(self, filter: str | None = None) -> str:
        return self._ops.list_plugin_params(channel_or_track=self.channel_or_track, slot=self.slot, filter=filter)

    def set(self, index: int, value: float) -> None:
        self._ops.set_plugin_param(channel_or_track=self.channel_or_track, slot=self.slot,
                                   param_index=checked_index(index), value=value)

    def find(self, name: str) -> PluginParameterInfo:
        matches = [item for item in self.list() if item.name == name]
        if len(matches) != 1:
            raise LookupError(f"Expected one parameter named {name!r}; found {len(matches)}.")
        return matches[0]


class Plugins:
    def __init__(self, ops: Operations) -> None:
        self._ops = ops

    def available_text(self, *, effects: bool = False) -> str:
        return self._ops.list_available_plugins(effects=effects)

    def samples_text(self, filter: str | None = None) -> str:
        return self._ops.list_samples(filter=filter)

    def channel_parameters(self, channel: int) -> Parameters:
        return Parameters(self._ops, channel)

    def effect_parameters(self, track: int, slot: int) -> Parameters:
        return Parameters(self._ops, track, checked_index(slot, maximum=9))
